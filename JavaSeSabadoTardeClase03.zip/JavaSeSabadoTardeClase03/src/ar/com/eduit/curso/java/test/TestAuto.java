package ar.com.eduit.curso.java.test;

import javax.swing.JOptionPane;
import ar.com.eduit.curso.java.entities.Auto;

public class TestAuto {

	public static void main(String[] args) {
		//El método main es el punto de entrada del proyecto
		//Una clase que tiene método main se puede ejecutar
		
		// Paradigma de Objetos
		
		//Objetos MOCKS (Objetos simulados)
		System.out.println("-- auto1 --");
		Auto auto1=new Auto();					//new Auto() llama al constructor de la clase Auto
		
		auto1.marca="Ford";
		auto1.modelo="Ka";
		auto1.color="Negro";
		
		auto1.acelerar();				//10
		auto1.acelerar();				//20
		auto1.acelerar();				//30
		auto1.frenar();					//20
		auto1.acelerar(25);				//45
		
		System.out.println(auto1.marca+", "+auto1.modelo+", "+auto1.color+", "+auto1.velocidad);
		
		System.out.println("-- auto2 --");
		Auto auto2=new Auto();
		auto2.marca="Fiat";
		auto2.modelo="Chronos";
		auto2.color="Verde";
		
		for(int a=0; a<=60; a++) auto2.acelerar();
		
		System.out.println(auto2.marca+", "+auto2.modelo+", "+auto2.color+", "+auto2.velocidad);
		System.out.println(auto2);
		
		System.out.println("-- auto3 --");
		Auto auto3=new Auto("Renault","Capture","Gris");
		auto3.acelerar(38);
		auto3.imprimirVelocidad();
		System.out.println(auto3.obtenerVelocidad());
		
		//JOptionPane.showMessageDialog(null, "Hola a todos!!");
		//JOptionPane.showMessageDialog(null, "Velocidad: "+auto3.obtenerVelocidad());

		//Método toString()
		System.out.println(auto3.toString());
		System.out.println(auto3);
		System.out.println(auto3.getEstado());

	}

}

