package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.interfaces.I_File;
import ar.com.eduit.curso.java.utils.files.FileBinary;
import ar.com.eduit.curso.java.utils.files.FileText;

public class TestFiles {
	public static void main(String[] args) {
		I_File fText;
		
		//fText=new FileText("texto.txt");
		fText=new FileBinary();
		
		fText.setText("Curso de Java!");
		System.out.println(fText.getText());
		
		
	}
}
