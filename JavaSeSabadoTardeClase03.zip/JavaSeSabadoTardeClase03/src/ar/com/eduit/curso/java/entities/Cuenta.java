package ar.com.eduit.curso.java.entities;

public final class Cuenta {
	
	private int nro;
	private String moneda;
	private double saldo;
	private final static double montoEnDescubierto=200000;
	
	public Cuenta(int nro, String moneda) {
		this.nro = nro;
		this.moneda = moneda;
	}
	
	public void depositar(double monto) {
		this.saldo+=monto;
	}
	
	//método final, no puede ser sobreescrito
	public final void debitar(double monto) {
		if(monto<=saldo) {
			this.saldo-=monto;
		}else {
			System.out.println("Saldo insuficiente");
		}
		
	}

	@Override
	public String toString() {
		return "Cuenta [nro=" + nro + ", moneda=" + moneda + ", saldo=" + saldo + "]";
	}

	public int getNro() {
		return nro;
	}

	public String getMoneda() {
		return moneda;
	}

	public double getSaldo() {
		return saldo;
	}

}
