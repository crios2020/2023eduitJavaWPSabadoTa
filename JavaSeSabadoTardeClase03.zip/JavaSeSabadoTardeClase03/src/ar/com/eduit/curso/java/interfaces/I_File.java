package ar.com.eduit.curso.java.interfaces;

public interface I_File {
	/*
	 * Una interface
	 * 	- no tiene atributos de clase, solo puede tener atributos estaticos o finales
	 *  - no tiene constructores
	 *  - todos sus miembros son publicos
	 *  - todos sus métodos son abstractos
	 *  - una clase puede implementar todas las interfaces que necesite
	 */
	
	void setText(String text);
	String getText();
	
	//metodos default JDK 8 o superior
	default void I_File_info() {
		//método default tiene cuerpo
		System.out.println("Interface I_File");
	}
	
}
