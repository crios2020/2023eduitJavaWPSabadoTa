package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestPolimorfismo {
	
	public static void main(String[] args) {
		Persona p1=new Vendedor("Andrea",46,null,1,600000);
		Persona p2=new Cliente("Matia",25,null,1,null);
		
		p1.saludar();		//saluda como vendedor
		p2.saludar();		//saluda como cliente
		
		Vendedor v1=(Vendedor)p1;
		
		System.out.println(v1.getClass());
		System.out.println(v1.getClass().getName());
		System.out.println(v1.getClass().getSimpleName());
		System.out.println(v1.getClass().getPackageName());
		System.out.println(v1.getClass().descriptorString());
		System.out.println(v1.getClass().getSuperclass().getName());
		System.out.println(v1.getClass().getSuperclass().getSuperclass().getName());
		System.out.println("texto".getClass().getName());
		System.out.println("texto".getClass().getSuperclass().getName());
		System.out.println(v1.getClass().getSuperclass().getSuperclass().getSuperclass());
		System.out.println(v1.getClass().getModifiers());							// 1
		System.out.println(v1.getClass().getSuperclass().getModifiers());			// 1025
		System.out.println(new Cuenta(1,"args").getClass().getModifiers());			// 17
		
		
		
	}
	
}
