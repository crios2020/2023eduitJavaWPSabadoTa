package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestDiagramaHerencia {
	public static void main(String[] args) {
		
		//Testeo por Objetos Mocks (Objetos simulados)
		
		System.out.println("-- direccion1 --");
		Direccion direccion1=new Direccion("Lavalle",648,"8","a");
		System.out.println(direccion1);
		
		System.out.println("-- direccion2 --");
		Direccion direccion2=new Direccion("Belgrano",48,null,null,"Morón");
		System.out.println(direccion2);
		
		/*
		System.out.println("-- persona1 --");
		Persona persona1=new Persona("Micaela", 48, direccion1);
		System.out.println(persona1);
		persona1.saludar();
		
		System.out.println("-- persona2 --");
		Persona persona2=new Persona("Alvaro",48, persona1.getDireccion());
		System.out.println(persona2);
		persona2.saludar();
		
		System.out.println("-- persona3 --");
		Persona persona3=new Persona("Julian",26,new Direccion("lima", 46, "8", "g"));
		System.out.println(persona3);
		persona3.saludar();
		
		System.out.println("-- persona4 --");
		Persona persona4=new Persona("Marian",34,new Direccion("lavalle",434,null, null));
		System.out.println(persona4);
		persona4.saludar();
		*/
		
		System.out.println("-- vendedor1 --");
		Vendedor vendedor1=new Vendedor("Florencia",46,direccion2,1,650000);
		System.out.println(vendedor1);
		vendedor1.saludar();
		
		System.out.println("-- cliente1 --");
		Cliente cliente1=new Cliente("Jacinto",29 , direccion1, 1, new Cuenta(1,"arg$"));
		cliente1.getCuenta().depositar(39000);
		System.out.println(cliente1);
		cliente1.saludar();
		
		
		
		
		
		
	}
}
