package ar.com.eduit.curso.java.utils.files;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import ar.com.eduit.curso.java.interfaces.I_File;

public class FileText implements I_File {
	
	private File file;
	
	public FileText(File file) {
		this.file = file;
	}
	
	public FileText(String file) {
		this.file = new File(file);
	}

	@Override
	public void setText(String text) {
		try (FileWriter out=new FileWriter(file)) {
			out.write(text);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public String getText() {
		String text="";
		int car;
		try (FileReader in=new FileReader(file)){
			while((car=in.read())!=-1) {
				text+=(char)car;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return text;
	}

}
