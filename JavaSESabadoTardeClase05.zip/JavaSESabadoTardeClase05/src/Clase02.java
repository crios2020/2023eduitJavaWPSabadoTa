import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

public class Clase02 {

	public static void main(String[] args) {
		// Clase 02
		
		// Arrays o vectores
		Auto[] autos=new Auto[4];
		autos[0]=new Auto("Fiat","Toro","Bordo");
		autos[1]=new Auto("Peugeot","Partner","Gris");
		autos[2]=new Auto("VW","Amarok","Blanca");
		autos[3]=new Auto("Honda","City","Azul");
		
		//Recorrido usando Indices
		//for(int a=0; a<autos.length; a++) {
		//	System.out.println(autos[a]);
		//}
		
		//Recorrido usando foreach
		for(Auto auto:autos) System.out.println(auto);
		
		//Interface List
		List<Auto>list;
		
		list=new ArrayList();
		//list=new LinkedList();
		//list=new Vector(); 
		
		list.add(new Auto("VW","GOL","Rojo"));					//0
		list.add(new Auto("Chevrolet","Corsa","Negro"));		//1
		list.add(new Auto("Honda","City","Azul"));				//2
		list.add(new Auto("Honda","City","Azul"));				//3
		//list.remove(0);
		
		//Copiar todos los autos del array autos a list
		//for(Auto auto:autos) list.add(auto);
		list.addAll(List.of(autos));
		
		System.out.println("************************************");
		//Recorrido con indices
		//for(int a=0; a<list.size(); a++) System.out.println(list.get(a));
		
		//Recorrido forEach
		//for(Auto auto:list) System.out.println(auto);
		
		//método forEach JDK 8
		//list.forEach(auto->System.out.println(auto));
		
		//list.forEach(auto->{
		//	System.out.println(auto);
		//});
		
		list.forEach(System.out::println);
		
		//list.forEach(auto->System.out.println(auto.getMarca()+" "+auto.getModelo()));
		
		//Imprimir los autos de color Rojo
//		list.forEach(auto->{
//			if(auto.getColor().equalsIgnoreCase("rojo")) {
//				System.out.println(auto);
//			}
//		});
		
		//Inteface Set
		Set<String> setSemana;
		
		//Implementación HashSet: Es la más veloz, no garantiza el orden de los elementos
		//setSemana=new HashSet();
			
		//Implementación LinkedHashSet: Almacena elementos por orden de ingreso en una lista enlazada
		//setSemana=new LinkedHashSet();
		
		//Implementación TreeSet:	Almacena elementos en arbol, por orden natural(Alfabeticamente) 
		setSemana=new TreeSet();
		
		//app
		setSemana.add("Lunes");
		setSemana.add("Martes");
		setSemana.add("Miércoles");
		setSemana.add("Jueves");
		setSemana.add("Viernes");
		setSemana.add("Sábado");
		setSemana.add("Domingo");
		setSemana.add("Lunes");
		setSemana.add("Lunes");
		setSemana.add("Martes");
		setSemana.add("Osvaldo");
		setSemana.forEach(System.out::println);
		
		/*
		 * Pila LIFO	(Last In First Out) (Ultimo en entrar es el primero en salir)
		 * Cola FIFO	(Fisrt In First Out)(Primer elemento en entrar es el primero en salir)
 		 * 
		 */
		
		//Pila
		Stack<Auto>pilaAutos=new Stack();
		pilaAutos.push(new Auto("Ford","Granada","Marron"));
		//.push() apila un elemento.
		
		pilaAutos.addAll(list);
		
		System.out.println("*****************************");
		pilaAutos.forEach(System.out::println);
		
		System.out.println("Longitud de pila: "+pilaAutos.size());
		while(!pilaAutos.isEmpty()) {
			System.out.println(pilaAutos.pop());
			//.pop() 	desapila un elemento
		}
		System.out.println("Longitud de pila: "+pilaAutos.size());
		
		//Cola
		ArrayDeque<Auto> colaAutos=new ArrayDeque();
		colaAutos.offer(new Auto("Renault","Clio","Verde"));
		//.offer() encola un elemento
		colaAutos.addAll(list);
		System.out.println("*****************************");
		colaAutos.forEach(System.out::println);
		
		System.out.println("Longitud de Cola: "+colaAutos.size());
		while(!colaAutos.isEmpty()) {
			System.out.println(colaAutos.poll());
			//.poll desencola elementos
		}
		System.out.println("Longitud de Cola: "+colaAutos.size());

		//Interface Map		Representa una lista del tipo (Llave, Valor) - Vector asociativo - Diccionario
		Map<String, String> mapaSemana=null;
		
		//mapaSemana=new HashMap();
		
		//mapaSemana=new Hashtable(); 			//Legacy		Obsoleta
		
		//mapaSemana=new LinkedHashMap();
		
		mapaSemana=new TreeMap();
		
		//app
		//mapaSemana en español
		mapaSemana.put("lu", "Lunes");
		mapaSemana.put("ma", "Martes");
		mapaSemana.put("mi", "Miércoles");
		mapaSemana.put("ju", "Jueves");
		mapaSemana.put("vi", "Viernes");
		mapaSemana.put("sa", "Sábado");
		mapaSemana.put("do", "Domingo");
		
		System.out.println(mapaSemana.get("vi"));
		System.out.println("**********************************");
		mapaSemana.forEach((k,v)->System.out.println(k+": "+v));
		
		
		//Propiedades de sistema
		System.out.println(System.getProperties());
		System.out.println(System.getProperty("java.version"));
		System.out.println("**********************************");
		System.getProperties().forEach((k,v)->System.out.println(k+": "+v));
		
		System.out.println(System.getProperty("user.language"));
		System.out.println(System.getProperty("os.arch"));
		
		System.out.println(System.getenv());
		System.out.println("**********************************");
		System.getenv().forEach((k,v)->System.out.println(k+": "+v));
		System.out.println(System.getenv().get("LOGNAME"));
		
		Set<Auto>setAutos=null;
		
		//setAutos=new LinkedHashSet();
		setAutos=new TreeSet();

		setAutos.addAll(list);
		setAutos.add(new Auto("Honda","Civic","Azul"));
		setAutos.add(new Auto("Honda","City","Azul"));
		setAutos.add(new Auto("Honda","City","Verde"));
		setAutos.add(new Auto("Honda","City","Rojo"));
		setAutos.add(new Auto("Honda","City","Blanco"));
		setAutos.add(new Auto("Honda","City","Amarillo"));
		
		System.out.println("**********************************");
		//setAutos.forEach(System.out::println);
		setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));
		
		
	}

}
