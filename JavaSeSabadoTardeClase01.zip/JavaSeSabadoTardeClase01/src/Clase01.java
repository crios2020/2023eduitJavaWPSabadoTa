import javax.swing.JOptionPane;

/**
 * Proyecto Clase 01 del curso Java Web Programming
 */
public class Clase01 {
	/**
	 * Punto de entrada del proyecto
	 * @param args Argumentos que ingresan desde consola
	 */
	public static void main(String[] args) {
		
		/*
		 * 
		 * Curso:	Java Web Programming		40 hs
		 * Días:	Sábado	15:00 a 18:hs
		 * Profe:	Carlos Rios		carlos.rios@educacionit.com
		 * 
		 * Materiales:		alumni.educacionit.com
		 * 						user:	email	
		 * 						pass:	dni
		 * 
		 * github:		https://github.com/crios2020/2023eduitJavaWPSabadoTa
		 * codeshare: 	https://codeshare.io/crios2020
		 * 
		 * https://www.youtube.com/watch?v=UXAltfkVCIw&list=PLMLmotKSEKYfobV2_eyZxVxc88E-27k7t
		 * 
		 * 
		 * JDK:			Java Development Kit	(Kit de Desarrollo Java)
		 * 		JDK 17 LTS
		 * Long Term Support	soporte extendido de 8 años
		 * 
		 * IDE:			Integrated Development Enviroment
		 * 			Eclipse	- VScode - SpringToolSuite - Netbeans - IntelliJ
		 *
		 * Git
		 */
		
		/* 
		 * Bloque
		 * De
		 * Comentarios
		 */
		/* Bloque de Comentarios */
		
		//Linea de comentarios
		
		//TODO Tarea pendiente
		
		/**
		 * Java DOC, es visible desde fuera del código binario
		 * Debe colocarse delante de la declaración de método o clase
		 */
		
		
		//Colores ANSI
		String black="\033[30m"; 
		String red="\033[31m"; 
		String green="\033[32m"; 
		String yellow="\033[33m"; 
		String blue="\033[34m"; 
		String purple="\033[35m"; 
		String cyan="\033[36m"; 
		String white="\033[37m";
		String reset="\u001B[0m";
		
		System.out.println(green+"Hola Mundo!"+reset);
		
		//JOptionPane.showMessageDialog(null, "Hola a todos");
		
		//Tipo de datos primitivos
		
		//Tipo de dato enteros
		
		//Tipo de datos boolean				1 byte
		boolean bo=true;
		System.out.println(bo);
		bo=false;
		System.out.println(bo);
		
		//Tipo de datos byte				1 byte
		byte by=100;
		System.out.println(by);
		by=-120;
		System.out.println(by);
		
		//Tipo de datos short				2 bytes
		short sh=2000;
		System.out.println(sh);
		
		//Tipo de datos int					4 bytes
		int in=2000000000;
		System.out.println(in);
		
		//Tipo de datos long				8 bytes
		long lo=3000000000L;
		System.out.println(lo);
		
		//Tipo de datos char				2 bytes
		char ch=65;
		System.out.println(ch);
		
		
		//Tipo de datos Punto flotante
		
		//Tipo de datos float	32 bits
		float fl=6.35f;
		System.out.println(fl);
		
		//Tipo de datos double	64 bits
		double dl=6.35;
		System.out.println(dl);
		
		fl=1;
		dl=1;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=10;
		dl=10;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=100;
		dl=100;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=1000;
		dl=1000;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=-10;
		dl=-10;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		//Clase String
		String st="Hola";
		System.out.println(st);

		
		String texto="Hola soy una cadena de texto!";
		System.out.println(texto);
		
		/*
		//Colores ANSI
		String black="\033[30m"; 
		String red="\033[31m"; 
		String green="\033[32m"; 
		String yellow="\033[33m"; 
		String blue="\033[34m"; 
		String purple="\033[35m"; 
		String cyan="\033[36m"; 
		String white="\033[37m";
		String reset="\u001B[0m";
		*/
		
		//Recorrido del vector
		for(int a=0; a<texto.length(); a++) {
			//System.out.print(red);
			if(a%2==0) 	System.out.print(red);
			else		System.out.print(blue);
			System.out.print(texto.charAt(a));
		}
		System.out.println(reset);
		System.out.println(black+"hola"+reset);
		
		for(int a=0; a<texto.length(); a++) {
			int resto=a%8;
			if(resto==0) System.out.print(black);
			if(resto==1) System.out.print(red);
			if(resto==2) System.out.print(green);
			if(resto==3) System.out.print(yellow);
			if(resto==4) System.out.print(blue);
			if(resto==5) System.out.print(purple);
			if(resto==6) System.out.print(cyan);
			if(resto==7) System.out.print(white);
			System.out.print(texto.charAt(a));
		}
		System.out.println(reset);
	}
}
