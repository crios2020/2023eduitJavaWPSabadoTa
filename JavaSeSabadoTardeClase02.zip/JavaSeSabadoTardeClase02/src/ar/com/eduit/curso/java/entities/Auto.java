package ar.com.eduit.curso.java.entities;

public class Auto { //Declaración de clase

	//atributos
	public String marca;
	public String modelo;
	public String color;
	public int velocidad;
	
	//Método constructor
	
	/**
	 * Método deprecado por Carlos Rios el 22/04/2023 por resultar inseguro
	 * usar en su reemplazo Auto(String marca, String modelo, String color)
	 */
	@Deprecated						//Anotation JDK 5 o superior
	public Auto(){
		//Constructor vacio
		//TODO Borrar este constructor el 22/04/2025
	} 
	
	public Auto(String marca, String modelo, String color){
		this.marca = marca;
		this.modelo = modelo;
		this.color = color;
	}
	
	//métodos
	public void acelerar() {
		//velocidad+=10;
		//if(velocidad>100) velocidad=100;
		acelerar(10);		//Llamado de método dentro de la misma clase
	}
	
	//Método sobrecargado
	public void acelerar(int kilometros) {
		velocidad+=kilometros;
		if(velocidad>100) velocidad=100;
	}
	
	public void frenar() {
		velocidad-=10;
	}
	
	public void imprimirVelocidad(){
		System.out.println(velocidad);
	}

	//Método con devolución de valor
	public int obtenerVelocidad(){
		return velocidad;
	}

	public String getEstado(){
		return marca+", "+modelo+", "+color+", "+velocidad;
	}

	@Override
	public String toString(){
		return marca+", "+modelo+", "+color+", "+velocidad;
	}

}//end class
