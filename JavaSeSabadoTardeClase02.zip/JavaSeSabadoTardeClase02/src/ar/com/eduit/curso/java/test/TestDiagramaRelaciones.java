package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;

public class TestDiagramaRelaciones {
	public static void main(String[] args) {
		
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1,"arg$");
		cuenta1.depositar(350000);
		cuenta1.depositar(140000);
		cuenta1.debitar(65000);
		System.out.println(cuenta1);
		
		System.out.println("-- clientePersona1 --");
		ClientePersona clientePersona1=new ClientePersona(1,"Javier",45,new Cuenta(2,"arg$"));
		clientePersona1.getCuenta().depositar(85000);
		System.out.println(clientePersona1);
		
		System.out.println("-- clienteMiguel --");
		ClientePersona clienteMiguel=new ClientePersona(2,"Miguel",40,new Cuenta(3,"arg$"));
		clienteMiguel.getCuenta().depositar(200000);
	
		System.out.println("-- clienteAna --");
		ClientePersona clienteAna=new ClientePersona(3,"Ana",40, clienteMiguel.getCuenta());
		clienteAna.getCuenta().debitar(100000);
		
		System.out.println(clienteMiguel);
		System.out.println(clienteAna);
		
		System.out.println("-- clientePersona2 --");
		ClientePersona clientePersona2=new ClientePersona(4,"Fernando",26,4,"arg$");
		clientePersona2.getCuenta().depositar(180000);
		clientePersona2.getCuenta().depositar(340000);
		clientePersona2.getCuenta().debitar(23000);
		System.out.println(clientePersona2);
		
		System.out.println("-- clientePersona3 --");
		ClientePersona clientePersona3=new ClientePersona(4,"Fernando",26,cuenta1);
		clientePersona2.getCuenta().depositar(180000);
		clientePersona2.getCuenta().depositar(340000);
		clientePersona2.getCuenta().debitar(23000);
		System.out.println(clientePersona3);
		
		System.out.println("-- clienteEmpresa1 --");
		ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(1,"Todo Limpio srl","Lima 234");
		clienteEmpresa1.getCuentas().add(new Cuenta(10,"arg$"));		//0
		clienteEmpresa1.getCuentas().add(new Cuenta(11,"reale$"));		//1
		clienteEmpresa1.getCuentas().add(new Cuenta(12,"U$S"));			//2
		clienteEmpresa1.getCuentas().get(0).depositar(450000);
		clienteEmpresa1.getCuentas().get(0).depositar(270000);
		clienteEmpresa1.getCuentas().get(0).debitar(34000);
		clienteEmpresa1.getCuentas().get(1).depositar(58000);
		clienteEmpresa1.getCuentas().get(2).depositar(34000);
		System.out.println(clienteEmpresa1);
		
		
	}
}
