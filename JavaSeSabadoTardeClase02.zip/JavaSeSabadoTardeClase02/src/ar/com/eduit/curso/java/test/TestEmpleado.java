package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Empleado;

public class TestEmpleado {
	public static void main(String[] args) {
		System.out.println("-- empleado1 --");
		Empleado empleado1=new Empleado(1,"Juan", "Loreto", 2323);
		//empleado1.sueldoBasico=9000000;
		empleado1.setSueldoBasico(9000000);
		System.out.println(empleado1);
		
	}
}
