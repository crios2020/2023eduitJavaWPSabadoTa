import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Clase04 {

	public static void main(String[] args) {
		// Clase 4 Manejo de Exceptions
		
		//System.out.println(10/0);
		//System.out.println("Esta sentencia no se ejecuta!");
		
		/*
		 * Estructura try - catch - finally
		 * 
		 * try{								//Obligatorio
		 * 
		 * 		// - Colocar aquí todas las sentencias que pueden arrojar una exception.
		 * 		// - Estas sentencias tienen más costo de hardware.
		 * 		// - Si este bloque se ejecuta correctamente, finaliza y transfiere el control
		 * 		// 		del programa al bloque finally o al final de esta estructura
		 * 		// - Si ocurre una exception (Error), el programa no se detiene. se transfiere
		 * 		//		el control del programa al bloque catch.
		 * 
		 * } catch(Exception e){			//Obligatorio
		 * 		// - Este bloque se ejecuta solamente en caso de Excpetion en bloque try.
		 * 		// - Se recibe como parámetro un objeto del tipo Exception. 
		 * 
		 * } finally {						//Opcional
		 * 		// - Este bloque siémpre se ejecuta, ocurra una exception o no!
		 * 		// - Las variables declaradas en bloque try o catch estan fuera de scope
		 * }
		 * 
		 *	// - Estas sentencias tambien siempre se ejecutan!
		 */
		
		/*
		try {
			System.out.println(10/0);
			System.out.println("Esta sentencia no se ejecuta!");
		} catch (Exception e) {
			System.out.println("Ocurrio un problema");
			System.out.println(e);
		} finally {
			System.out.println("Termino la estructura");
		}
		System.out.println("Fin del programa!");
		*/
		
		try {
			//GeneradorDeExceptions.generar();
			//GeneradorDeExceptions.generar(true);
			//GeneradorDeExceptions.generar("65v");
			//GeneradorDeExceptions.generar(null, 2);
			//GeneradorDeExceptions.generar("hola", 20);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		//Las UncheckedException (RuntimeException) no tenemos la obligación de controlarlas
		//Las CheckedException tenemos la obligación de controlarlas
		
		//GeneradorDeExceptions.generar(true);	//Puede lanzar una uncheckedException
		
		try {
			//FileReader in=new FileReader("texto.txt");
		}catch(Exception e) {
			System.out.println(e);
		}
		
		//Captura personalizada de Exceptions
		
		
		try {
			//GeneradorDeExceptions.generar();
			//GeneradorDeExceptions.generar(true);
			//GeneradorDeExceptions.generar("38v");
			//GeneradorDeExceptions.generar(null, 2);
			//GeneradorDeExceptions.generar("hola", 20);
			FileReader in=new FileReader("texto.txt");
		//} catch (StringIndexOutOfBoundsException e)	{ System.out.println("Indice Fuera de Rango!");
		} catch (NumberFormatException e) 			{ System.out.println("Numero Incorrecto!");
		} catch (NullPointerException e) 			{ System.out.println("Puntero Nulo!");
		//} catch (ArrayIndexOutOfBoundsException e) 	{ System.out.println("Indice Fuera de Rango!");
		} catch (ArithmeticException e) 			{ System.out.println("Error División /0!");
		//} catch (StringIndexOutOfBoundsException | ArrayIndexOutOfBoundsException e) { System.out.println("Indice Fuera de Rango!");
		} catch (IndexOutOfBoundsException e)		{ System.out.println("Indice Fuera de Rango!");
		} catch (FileNotFoundException e)			{ System.out.println("No se encontro el archivo!");
		} catch (IOException e)						{ System.out.println("Error IO!");
		} catch (Exception e) 						{ System.out.println("Ocurrio un error no esperado!");
		}
		
		
		//Uso de Exceptions para validar reglas de negocio
		Vuelo vuelo1=new Vuelo("AER1234",100);
		Vuelo vuelo2=new Vuelo("FLB1111",100);
		
		try {
			vuelo1.venderPasajes(50);
			vuelo2.venderPasajes(20);
			vuelo1.venderPasajes(30);
			vuelo2.venderPasajes(20);
			vuelo1.venderPasajes(35);			//Lanza una exception
			vuelo2.venderPasajes(10);			//Esta venta no se hace
		} catch (NoHayMasPasajesException e) {
			System.out.println(e);
		}
		
		
		
		//No hacer esto!!!
		FileWriter out=null;
		try {
			out=new FileWriter("texto.txt");
			out.write("hola");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(out!=null) {
				try {
					out.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}


		//Try with Resources			JDK 7 o sup
		try (FileWriter salida=new FileWriter("texto.txt")){
			salida.write("hola");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		
	}

}
