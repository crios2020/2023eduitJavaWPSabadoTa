
public class GeneradorDeExceptions {
	
	public static void generar() {
		int[] vector=new int[5];
		vector[10]=20;						//ArrayIndexOutOfBoundsException
	}
	
	public static void generar(boolean x) {
		if(x) System.out.println(10/0);		//ArithmeticException
	}
	
	public static void generar(String nro) {	//NumberFormatException
		int n=Integer.parseInt(nro);
	}
	
	public static void generar(String text, int index) {
		//if(text==null || index<0 || index>=text.length()) return;
		System.out.println(text.charAt(index));	//NullPointerException	|| StringIndexOutOfBoundsException         
	}
	
}
